export const TEST_TYPE = 'TEST_TYPE'
export const TEST_SET_MENU = 'TEST_GET_MENU'