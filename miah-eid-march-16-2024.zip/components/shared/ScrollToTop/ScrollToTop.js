import React from 'react'

export default function ScrollToTop() {
  return (
    <button className="btn scroll-top">
      <i className="fa fa-angle-double-up"></i>
    </button>
  )
}
