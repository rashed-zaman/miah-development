import React from 'react'

export default function Search() {
  return (
    <div className="ps-search">
      {/* <div className="ps-search__content ps-search--mobile">
        <a className="ps-search__close" href="#" id="close-search"
          ><img src="img/icon/close.svg" alt=""
        /></a>
        <h3>Search</h3>
        <form action="do_action" method="post">
          <div className="ps-search-table">
            <div className="input-group">
              <input
                className="form-control ps-input"
                type="text"
                placeholder="Search"
              />
              <div className="input-group-append">
                <a href="#"><img src="img/icon/search.svg" alt="" /></a>
              </div>
            </div>
          </div>
        </form>
        <div className="ps-search__result">
          <div className="ps-product ps-product--horizontal">
            <div className="ps-product__thumbnail">
              <a className="ps-product__image" href="product-1.html">
                <figure><img src="img/products/26.jpg" alt="alt" /></figure>
              </a>
            </div>
            <div className="ps-product__content">
              <h5 className="ps-product__title">
                <a href="product-1.html"
                  >Dark blue classic long sleeves shirt</a
                >
              </h5>
              <div className="ps-product__desc">
                <ul className="ps-product__list">
                  <li>Study history up to 30 days</li>
                  <li>Up to 5 users simultaneously</li>
                  <li>Has HEALTH certificate</li>
                </ul>
              </div>
              <div className="ps-product__meta">
                <span className="ps-product__price">$117.00</span>
              </div>
            </div>
          </div>
          <div className="ps-product ps-product--horizontal">
            <div className="ps-product__thumbnail">
              <a className="ps-product__image" href="product-1.html">
                <figure><img src="img/products/6.jpg" alt="alt" /></figure>
              </a>
            </div>
            <div className="ps-product__content">
              <h5 className="ps-product__title">
                <a href="product-1.html">White short checkered T-shirt</a>
              </h5>
              <div className="ps-product__desc">
                <ul className="ps-product__list">
                  <li>Study history up to 30 days</li>
                  <li>Up to 5 users simultaneously</li>
                  <li>Has HEALTH certificate</li>
                </ul>
              </div>
              <div className="ps-product__meta">
                <span className="ps-product__price">$35.00</span>
              </div>
            </div>
          </div>
          <div className="ps-product ps-product--horizontal">
            <div className="ps-product__thumbnail">
              <a className="ps-product__image" href="product-1.html">
                <figure><img src="img/products/12.jpg" alt="alt" /></figure>
              </a>
            </div>
            <div className="ps-product__content">
              <h5 className="ps-product__title">
                <a href="product-1.html">Blue classic long sleeves shirt</a>
              </h5>
              <div className="ps-product__desc">
                <ul className="ps-product__list">
                  <li>Study history up to 30 days</li>
                  <li>Up to 5 users simultaneously</li>
                  <li>Has HEALTH certificate</li>
                </ul>
              </div>
              <div className="ps-product__meta">
                <span className="ps-product__price sale">$20.00</span
                ><span className="ps-product__del">$26.00</span>
              </div>
            </div>
          </div>
          <div className="ps-search__more">
            <a href="shop-result.html">View all 8 results</a>
          </div>
        </div>
      </div> */}
    </div>
  )
}
