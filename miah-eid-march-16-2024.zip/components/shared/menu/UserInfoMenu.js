import React from 'react';

export default function UserInfoMenu() {
  return <div></div>;
}
