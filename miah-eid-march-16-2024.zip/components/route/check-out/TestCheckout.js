import React from 'react'

export default function TestCheckout({price}) {
  return (
    <div>
      <p>
        { price }
      </p>
    </div>
  )
}
