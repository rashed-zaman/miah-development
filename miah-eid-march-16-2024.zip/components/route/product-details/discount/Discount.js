import React from "react";

export default function Discount() {
  return (
    <div className="discountPurchase">
      <p>GET 100 TAKA CASHBACK ON YOUR FIRST SUCCESSFUL PURCHASE</p>
      <p>
        {/* <small>Buy 4 or more to get the multibuy price</small> */}
      </p>
    </div>
  );
}
